from utils import *

class CB1(nn.Module):
    def __init__(self, in_channels, out_channels, use_bn=True, use_relu=True):
        super(CB1, self).__init__()
        self.use_bn = use_bn
        self.use_relu = use_relu
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        if self.use_bn:
            self.bn = nn.BatchNorm2d(out_channels)
    def forward(self, x):
        y = self.conv(x)
        if self.use_bn:
            y = self.bn(y)
        if self.use_relu:
            y = F.relu(y)
        return y
    
class CB3(nn.Module):
    def __init__(self, in_channels, out_channels, use_bn=True, use_relu=True):
        super(CB3, self).__init__()
        self.use_bn = use_bn
        self.use_relu = use_relu
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1, bias=False)
        if self.use_bn:
            self.bn = nn.BatchNorm2d(out_channels)
    def forward(self, x):
        y = self.conv(x)
        if self.use_bn:
            y = self.bn(y)
        if self.use_relu:
            y = F.relu(y)
        return y

class FC(nn.Module):
    def __init__(self, in_channels, out_channels, use_bn=True, use_relu=True):
        super(FC, self).__init__()
        self.use_bn = use_bn
        self.use_relu = use_relu 
        self.linear = nn.Linear(in_channels, out_channels, bias=False)
        if self.use_bn:
            self.bn = nn.BatchNorm1d(out_channels)
    def forward(self, x):
        y = self.linear(x)
        if self.use_bn:
            y = self.bn(y)
        if self.use_relu:
            y = F.relu(y)
        return y
        
        
class ChannelAttention(nn.Module):
    def __init__(self, in_channels, sqz_ratio=4):
        super(ChannelAttention, self).__init__()
        self.avg_pooling = nn.AdaptiveAvgPool2d(1)
        self.max_pooling = nn.AdaptiveMaxPool2d(1)
        self.fc_1 = FC(in_channels, in_channels//sqz_ratio, True, True)
        self.fc_2 = FC(in_channels//sqz_ratio, in_channels, True, False) 
    def forward(self, ftr):
        avg_out = self.avg_pooling(ftr).squeeze(-1).squeeze(-1)
        max_out = self.max_pooling(ftr).squeeze(-1).squeeze(-1) 
        avg_weights = self.fc_2(self.fc_1(avg_out))
        max_weights = self.fc_2(self.fc_1(max_out))
        weights = F.sigmoid(avg_weights + max_weights) 
        return ftr * weights.unsqueeze(-1).unsqueeze(-1) + ftr

    
class SpatialAttention(nn.Module):
    def __init__(self):
        super(SpatialAttention, self).__init__()
        self.fuse = CB3(2, 1, False, False)
    def forward(self, ftr):
        avg_out = torch.mean(ftr, dim=1, keepdim=True) 
        max_out = torch.max(ftr, dim=1, keepdim=True)[0] 
        cat_out = torch.cat([avg_out, max_out], dim=1) 
        sam = F.sigmoid(self.fuse(cat_out)) 
        return sam*ftr + ftr

class BackboneBuilder(nn.Module):
    def __init__(self, bb_load_path='./Checkpoints/warehouse/backbone_v.pth'):
        super(BackboneBuilder, self).__init__()
        dr = [1, 1/2, 1/4, 1/8, 1/8]
        ch = [64, 128, 256, 512, 512]
        self.bb = torch.load(bb_load_path)
        self.SA_1 = SpatialAttention()
        self.SA_2 = SpatialAttention()
        self.SA_3 = SpatialAttention()
        self.CA_4 = ChannelAttention(ch[3])
        self.CA_5 = ChannelAttention(ch[4]) 
    def forward(self, Im):
        F1 = self.SA_1(self.bb.C1(Im))
        F2 = self.SA_2(self.bb.C2(F1)) 
        F3 = self.SA_3(self.bb.C3(F2))
        F4 = self.CA_4(self.bb.C4(F3)) 
        F5 = self.CA_5(self.bb.C5(F4))
        return F5

class co_att(nn.Module):

    def __init__(self,in_dim):
        super(co_att,self).__init__()
        self.chanel_in = in_dim
        self.query_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim , kernel_size= 1)
        self.key_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim , kernel_size= 1)
        self.value_conv = nn.Conv2d(in_channels = in_dim , out_channels = in_dim , kernel_size= 1)
        self.softmax  = nn.Softmax(dim=-1) 
    def forward(self,x,y):
        m_batchsize,C,width ,height = x.size()
        xproj_query  = self.query_conv(x).view(m_batchsize,-1,width*height).permute(0,2,1) 
        yproj_key =  self.key_conv(y).view(m_batchsize,-1,width*height)
        energy = torch.bmm(xproj_query,yproj_key)
        energy = torch.max(energy , dim=2, keepdim=True)[0] 
        attention = self.softmax(energy).view(m_batchsize,1,width,height)
        xout = x * attention + x
        return xout
    
class AEWF(nn.Module):
    def __init__(self, in_channels):
        super(AEWF, self).__init__()
        self.channel_reduction = CB1(in_channels*2, in_channels, True, True)
        self.importance_estimator = nn.Sequential(ChannelAttention(in_channels),
                                   CB3(in_channels, in_channels//2, True, True),
                                   CB3(in_channels//2, in_channels//2, True, True),
                                   CB3(in_channels//2, in_channels, True, False), nn.Sigmoid())
    def forward(self, group_semantics, individual_features):
        ftr_concat_reduc = self.channel_reduction(torch.cat((group_semantics, individual_features), dim=1)) 
        P = self.importance_estimator(ftr_concat_reduc) 
        co_saliency_features = group_semantics * P + individual_features * (1-P) 
        return co_saliency_features  

    
class DE(nn.Module):
    def __init__(self, in_channels):
        super(DE, self).__init__()
        self.channel_reduction = CB1(in_channels, in_channels//2, True, True)
        self.deconv = CB3(in_channels//2, in_channels//2, True, True)
    def forward(self, X): 
        [B, M, D, H, W] = X.size()
        X_US2 = self.deconv(US2(self.channel_reduction(X.view(B*M, D, H, W)))) 
        return X_US2.view(B, M, D//2, 2*H, 2*W)
    
    
class CosalHead(nn.Module):
    def __init__(self, in_channels):
        super(CosalHead, self).__init__()
        self.output = nn.Sequential(CB3(in_channels, in_channels*4, True, True),
                           CB3(in_channels*4, in_channels*4, True, True),
                           CB3(in_channels*4, 1, False, False), nn.Sigmoid())
    def forward(self, x):
        return self.output(x)
        
    