from utils import *


def dataset_mean_std(dataset):
    assert dataset in ['Cosal2015', 'CoSOD3k', 'iCoseg', 'MSRC']
    if dataset == 'Cosal2015':
        mean, std = [0.4898, 0.4624, 0.3941], [0.2175, 0.2139, 0.2109]
    if dataset == 'CoSOD3k':
        mean, std = [0.4883, 0.4642, 0.4083], [0.2180, 0.2138, 0.2135]
    if dataset == 'iCoseg':
        mean, std = [0.5129, 0.5223, 0.4806], [0.2080, 0.2021, 0.2025]
    if dataset == 'MSRC':
        mean, std = [0.5017, 0.5012, 0.4333], [0.2248, 0.2182, 0.2371]
    return mean, std


class List_Loader(data.Dataset):
    def __init__(self, root, list_file_name, mean, std, aug=False):
        self.root = root
        self.aug = aug
        with open(os.path.join(root, list_file_name), 'r') as list_file:
            self.local_paths = list_file.read().splitlines()
        self.ti = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean, std)])
        self.tl = transforms.Compose([transforms.ToTensor()])
        self.flip_h = transforms.RandomHorizontalFlip(p=1)
    def __getitem__(self, index):
        local_path = self.local_paths[index]
        image_path = os.path.join(self.root, local_path + '.jpg')
        label_path = os.path.join(self.root, local_path + '.png')
        if self.aug:
            r = np.random.random()
            if r > 0.5:
                image = self.ti(self.flip_h(Image.open(image_path)))
                label = self.tl(self.flip_h(Image.open(label_path)))
            else:
                image = self.ti(Image.open(image_path))
                label = self.tl(Image.open(label_path)) 
        else:
            image = self.ti(Image.open(image_path))
            label = self.tl(Image.open(label_path))   
        return image, label, local_path
    def __len__(self):
        return len(self.local_paths)
    

def CoSOD_Dataset_Parser(dataset_root, info_file, list_file):
    with open(os.path.join(dataset_root, info_file), 'r') as f:
        contents = f.read().splitlines()
    GroupNumbers = len(contents)
    GroupNames, GroupSizes = [], []
    for c in contents:
        g_name, g_size = c.split(' ')
        g_size = int(g_size)
        GroupNames.append(g_name)
        GroupSizes.append(g_size)   
    with open(os.path.join(dataset_root, list_file), 'r') as f:
        local_paths = f.read().splitlines()
    S = []
    for i in range(GroupNumbers):
        s = 0
        for j in range(i+1):
            s += GroupSizes[j]
        S.append(s)
    GroupFileLists = []
    for sid in range(GroupNumbers):
        if sid == 0:
            start_index = 0
            end_index = S[0]
        else:
            start_index = S[sid-1]
            end_index = S[sid]
        gr_file_list = []
        for index in range(start_index, end_index):
            gr_file_list.append(local_paths[index])
        GroupFileLists.append(gr_file_list)
    return GroupNumbers, GroupNames, GroupSizes, GroupFileLists


def Random_Batch_Group_Loader(dataset_root, GroupNumbers, GroupFileLists, B, M, dataset_mean, dataset_std):
    ti = transforms.Compose([transforms.ToTensor(), transforms.Normalize(dataset_mean, dataset_std)])
    tl = transforms.ToTensor()
    group_ids = random.choice(GroupNumbers, B, replace=False)
    batch_group_images_bag = []
    batch_group_labels_bag = []
    batch_group_names_bag = []
    for g in group_ids:
        group_file_list = GroupFileLists[g]
        image_ids = random.choice(len(group_file_list), M, replace=False)
        images_bag = []
        labels_bag = []
        names_bag = []
        for i in image_ids:
            local_path = group_file_list[i]
            names_bag.append(local_path)
            images_bag.append(ti(Image.open(os.path.join(dataset_root, local_path+'.jpg'))).unsqueeze(0))
            labels_bag.append(tl(Image.open(os.path.join(dataset_root, local_path+'.png'))).unsqueeze(0))
        batch_group_images_bag.append(torch.cat(images_bag,dim=0).unsqueeze(0))
        batch_group_labels_bag.append(torch.cat(labels_bag,dim=0).unsqueeze(0))
        batch_group_names_bag.append(names_bag)
    batch_group_images = torch.cat(batch_group_images_bag, dim=0) 
    batch_group_labels = torch.cat(batch_group_labels_bag, dim=0)
    return batch_group_images, batch_group_labels, batch_group_names_bag

