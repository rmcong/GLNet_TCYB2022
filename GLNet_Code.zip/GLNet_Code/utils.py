from packages import *


def US2(x):
    return F.interpolate(x, scale_factor=2, mode='bilinear')


def US4(x):
    return F.interpolate(x, scale_factor=4, mode='bilinear')


def US8(x):
    return F.interpolate(x, scale_factor=8, mode='bilinear')


def DS2(x):
    return F.max_pool2d(x, 2)


def DS4(x):
    return F.max_pool2d(x, 4)


def DS8(x):
    return F.max_pool2d(x, 8)


def align_number(number, N):
    assert type(number) == int
    num_str = str(number)
    assert len(num_str) <= N
    return (N-len(num_str))*'0' + num_str


def show_image_tensor(im, dataset_mean, dataset_std):
    im = im.cpu().squeeze()
    dt_mean = torch.Tensor(dataset_mean).view(3,1,1)
    dt_std = torch.Tensor(dataset_std).view(3,1,1)
    unloader = transforms.ToPILImage()
    im_ori = im * dt_std + dt_mean
    return unloader(im_ori)


def show_label_tensor(label):
    return Image.fromarray(min_max_normalization(unload(label))*255).convert('L')


def load_image_as_tensor(image_full_path):
    loader = transforms.ToTensor()
    image_tensor = loader(Image.open(image_full_path)) # [C, H, W], [0, 1]
    image_tensor_batch = image_tensor.unsqueeze(0) # add batch dimension, [1, C, H, W]
    return image_tensor_batch 


def unload(x):
    y = x.squeeze().cpu().data.numpy()
    return y


def min_max_normalization(x):
    x_normed = (x - np.min(x)) / (np.max(x)-np.min(x))
    return x_normed


def convert2img(x):
    return Image.fromarray(x*255).convert('L')


def save_smap(smap, path, negative_threshold=0.25):
    # smap: [1, H, W]
    if torch.max(smap) <= negative_threshold:
        smap[smap<negative_threshold] = 0
        smap = convert2img(unload(smap))
    else:
        smap = convert2img(min_max_normalization(unload(smap)))
    smap.save(path)


def cache_model(model, path, multi_gpu):
    if multi_gpu:
        torch.save(model.module.state_dict(), path)
    else:
        torch.save(model.state_dict(), path)
        
        
